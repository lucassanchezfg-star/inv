/* =============================================================================
   Círculo de Competência — aplicação
   Vanilla JS, sem dependências. Roteamento por hash.
   ========================================================================== */

(function () {
  'use strict';

  var D = window.DADOS;
  if (!D) { return; }

  /* ------------------------------------------------------------ utilidades */

  var $ = function (sel, root) { return (root || document).querySelector(sel); };
  var $$ = function (sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); };

  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  function nf(v, dec) {
    return v.toLocaleString('pt-BR', { minimumFractionDigits: dec, maximumFractionDigits: dec });
  }

  /** US$ 299,3 bi | US$ 326,7 mi */
  function usd(v, aprox) {
    var pre = aprox ? '~US$ ' : 'US$ ';
    if (v >= 1e9) { return pre + nf(v / 1e9, 1) + ' bi'; }
    if (v >= 1e6) { return pre + nf(v / 1e6, 1) + ' mi'; }
    return pre + nf(v, 0);
  }

  function pct(v, dec) {
    if (v == null) { return 'n/d'; }
    return nf(v, dec == null ? 2 : dec) + '%';
  }

  /* ------------------------------------------------------------- cotações */

  // data/cotacoes.js é gerado por atualizar_cotacoes.py. Se não houver dados,
  // COT fica null e todas as colunas de preço desaparecem da interface.
  var COT = (window.COTACOES && window.COTACOES.precos &&
             Object.keys(window.COTACOES.precos).length) ? window.COTACOES : null;

  function cot(ticker) {
    return COT ? (COT.precos[ticker] || null) : null;
  }

  function preco(ticker) {
    var c = cot(ticker);
    return c ? 'US$ ' + nf(c.p, 2) : '—';
  }

  /** variação desde a data-base do 13F, colorida pelos tokens semânticos */
  function varBase(ticker) {
    var c = cot(ticker);
    if (!c || c.var == null) { return '<span class="setor">—</span>'; }
    var cor = c.var > 0 ? 'var(--pos)' : c.var < 0 ? 'var(--neg)' : 'var(--ink-2)';
    var sinal = c.var > 0 ? '+' : '';
    return '<span class="peso" style="color:' + cor + '">' + sinal + nf(c.var, 1) + '%</span>';
  }

  function dataCotacao() {
    if (!COT) { return ''; }
    var datas = Object.keys(COT.precos).map(function (k) { return COT.precos[k].d; })
      .filter(Boolean).sort();
    var d = datas.length ? datas[datas.length - 1] : null;
    if (!d) { return ''; }
    var partes = d.split('-');
    return partes.length === 3 ? partes[2] + '/' + partes[1] + '/' + partes[0] : d;
  }

  function chaveEmpresa(nome) {
    return String(nome).toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]/g, '');
  }

  /* --------------------------------------------------- derivações da base */

  D.gestores.forEach(function (g) {
    var somaListada = g.posicoesDetalhe.reduce(function (a, h) { return a + (h.p || 0); }, 0);
    g._somaListada = somaListada;
    g._resto = Math.max(0, Math.round((100 - somaListada) * 100) / 100);
    g._divulgadas = g.posicoesDetalhe.length;
    g._comPeso = g.posicoesDetalhe.filter(function (h) { return h.p != null; }).length;

    // concentração: peso das cinco maiores posições divulgadas
    var ord = g.posicoesDetalhe.slice().sort(function (a, b) { return (b.p || 0) - (a.p || 0); });
    g._top5 = ord.slice(0, 5).reduce(function (a, h) { return a + (h.p || 0); }, 0);
    g._maior = ord[0];

    // agrupa classes da mesma empresa (Alphabet A + C)
    var porEmpresa = {};
    g.posicoesDetalhe.forEach(function (h) {
      var k = chaveEmpresa(h.n);
      if (!porEmpresa[k]) { porEmpresa[k] = { nome: h.n, setor: h.s, peso: 0, tickers: [], mov: null, movNota: null }; }
      var e = porEmpresa[k];
      e.peso += (h.p || 0);
      e.tickers.push(h.t);
      if (h.mov && !e.mov) { e.mov = h.mov; e.movNota = h.movNota; }
    });
    g._empresas = porEmpresa;
  });

  var totalCarteiras = D.gestores.reduce(function (a, g) { return a + g.valor; }, 0);
  var totalPosicoes = D.gestores.reduce(function (a, g) { return a + g.posicoes; }, 0);

  /* --------------------------------------------------------- consenso ----- */

  var consenso = (function () {
    var mapa = {};
    D.gestores.forEach(function (g) {
      Object.keys(g._empresas).forEach(function (k) {
        var e = g._empresas[k];
        if (!mapa[k]) { mapa[k] = { chave: k, nome: e.nome, setor: e.setor, tickers: {}, donos: [] }; }
        e.tickers.forEach(function (t) { mapa[k].tickers[t] = 1; });
        mapa[k].donos.push({ gestor: g, peso: e.peso, mov: e.mov });
      });
    });
    return Object.keys(mapa).map(function (k) {
      var it = mapa[k];
      it.tickersArr = Object.keys(it.tickers);
      it.n = it.donos.length;
      it.donos.sort(function (a, b) { return b.peso - a.peso; });
      it.pesoMedio = it.donos.reduce(function (a, d) { return a + d.peso; }, 0) / it.n;
      it.pesoMax = it.donos[0].peso;
      return it;
    }).sort(function (a, b) {
      return (b.n - a.n) || (b.pesoMedio - a.pesoMedio) || a.nome.localeCompare(b.nome, 'pt-BR');
    });
  })();

  var totalEmpresas = consenso.length;
  var compartilhadas = consenso.filter(function (c) { return c.n > 1; });

  /* ------------------------------------------------------- componentes --- */

  var MOV_LABEL = { novo: 'nova', add: 'aumentou', trim: 'reduziu' };

  function tagMov(mov) {
    if (!mov) { return ''; }
    return '<span class="tag tag--' + mov + '">' + MOV_LABEL[mov] + '</span>';
  }

  function botaoTicker(t, cls) {
    return '<button class="tk" data-tk="' + esc(t) + '">' + esc(t) + '</button>' +
      (cls ? '<span class="cls">' + esc(cls) + '</span>' : '');
  }

  function barraEmpilhada(g) {
    var ord = g.posicoesDetalhe.slice().sort(function (a, b) { return (b.p || 0) - (a.p || 0); });
    var segs = ord.filter(function (h) { return h.p; }).map(function (h, i) {
      // rampa de latão: mais escuro/saturado nas maiores posições
      var op = 1 - Math.min(0.66, i * 0.075);
      return '<span class="stack__seg" style="width:' + h.p + '%;background:var(--bar);opacity:' + op.toFixed(2) + '" ' +
        'title="' + esc(h.t) + ' — ' + pct(h.p) + '"></span>';
    }).join('');
    var resto = g._resto > 0.01
      ? '<span class="stack__seg stack__seg--rest" style="width:' + g._resto + '%" title="Demais posições — ' + pct(g._resto) + '"></span>'
      : '';
    return '<div class="stack" role="img" aria-label="Alocação: ' + pct(g._somaListada, 1) +
      ' em ' + g._divulgadas + ' posições divulgadas">' + segs + resto + '</div>';
  }

  function cardGestor(g) {
    return '<button class="card" data-goto="#/g/' + g.id + '">' +
      '<span class="card__top">' +
        '<span class="sigla">' + esc(g.sigla) + '</span>' +
        '<span><span class="card__name">' + esc(g.nome) + '</span>' +
        '<br><span class="card__firm">' + esc(g.gestora) + '</span></span>' +
      '</span>' +
      '<span class="card__figs">' +
        '<span><span class="fig__v">' + usd(g.valor, g.valorAprox) + '</span>' +
        '<br><span class="fig__l">Carteira 13F</span></span>' +
        '<span><span class="fig__v">' + (g.posicoesAprox ? '~' : '') + nf(g.posicoes, 0) + '</span>' +
        '<br><span class="fig__l">Posições</span></span>' +
        '<span><span class="fig__v">' + pct(g._top5, 0) + '</span>' +
        '<br><span class="fig__l">Top 5</span></span>' +
      '</span>' +
      '<span class="card__lema">“' + esc(g.lema) + '”</span>' +
      barraEmpilhada(g) +
      '<span class="card__foot">Maior posição: <strong>' + esc(g._maior.t) + '</strong> ' +
        pct(g._maior.p, 1) + '<span class="card__cta">ver carteira →</span></span>' +
    '</button>';
  }

  function chipGestor(dono, comPeso) {
    return '<button class="chip" data-goto="#/g/' + dono.gestor.id + '">' +
      esc(dono.gestor.nome) +
      (comPeso ? ' <span class="num">' + pct(dono.peso, 1) + '</span>' : '') +
      '</button>';
  }

  function linhaConsenso(c, rank) {
    var dots = '';
    for (var i = 0; i < D.gestores.length; i++) {
      dots += '<span class="dot' + (i < c.n ? '' : ' dot--off') + '"></span>';
    }
    return '<div class="crow">' +
      '<span class="crow__rank">' + rank + '</span>' +
      '<span class="crow__co"><b>' + esc(c.nome) + '</b><br>' +
        '<span class="crow__tk">' + c.tickersArr.map(esc).join(' · ') + ' · ' + esc(c.setor) + '</span></span>' +
      '<span class="crow__n"><span class="num">' + c.n + '</span><span class="dots">' + dots + '</span></span>' +
      '<span class="crow__who">' + c.donos.map(function (d) { return chipGestor(d, true); }).join('') + '</span>' +
    '</div>';
  }

  /* ------------------------------------------------------------ panorama - */

  function viewPanorama() {
    var destaques = consenso.filter(function (c) { return c.n > 1; }).slice(0, 8);

    return '<div class="wrap">' +
      '<p class="eyebrow">13F · ' + esc(D.meta.competencia) + ' · base ' + esc(D.meta.dataBase) + '</p>' +
      '<h1 class="lede">Oito investidores que compram empresas, não cotações — e o que eles tinham na mão no fim de junho.</h1>' +
      '<p class="sub">Cada carteira abaixo vem do formulário 13F-HR entregue à SEC. O 13F mostra ações listadas nos ' +
      'EUA e nada mais: caixa, títulos, imóveis e participações em empresas fechadas ficam de fora. ' +
      'Leia como mapa de convicção, não como retrato do patrimônio.</p>' +

      '<div class="strip">' +
        '<div class="strip__cell"><div class="strip__val">' + D.gestores.length + '</div><div class="strip__lab">gestores acompanhados</div></div>' +
        '<div class="strip__cell"><div class="strip__val">' + usd(totalCarteiras) + '</div><div class="strip__lab">somados em ações americanas</div></div>' +
        '<div class="strip__cell"><div class="strip__val">~' + nf(totalPosicoes, 0) + '</div><div class="strip__lab">posições declaradas</div></div>' +
        '<div class="strip__cell"><div class="strip__val">' + compartilhadas.length + ' <span style="font-size:13px;color:var(--ink-3)">de ' + totalEmpresas + '</span></div><div class="strip__lab">empresas em mais de uma carteira</div></div>' +
      '</div>' +

      '<section class="section">' +
        '<div class="section__head">' +
          '<h2>Onde as carteiras se cruzam</h2>' +
          '<p class="section__note">Empresas que aparecem em duas ou mais carteiras, com o peso que cada gestor deu a ela. ' +
          'Classes diferentes da mesma empresa entram somadas.</p>' +
          '<button class="chip push" data-goto="#/consenso">ver as ' + totalEmpresas + ' empresas →</button>' +
        '</div>' +
        '<div class="consensus">' +
          '<div class="crow crow--head"><span></span><span>Empresa</span><span>Gestores</span><span>Quem detém e com que peso</span></div>' +
          destaques.map(function (c, i) { return linhaConsenso(c, i + 1); }).join('') +
        '</div>' +
      '</section>' +

      '<section class="section">' +
        '<div class="section__head">' +
          '<h2>As oito carteiras</h2>' +
          '<p class="section__note">Ordenadas por concentração: de quem cabe em quatro nomes a quem espalha por centenas.</p>' +
        '</div>' +
        '<div class="grid-gestores">' +
          D.gestores.slice().sort(function (a, b) { return b._top5 - a._top5; }).map(cardGestor).join('') +
        '</div>' +
      '</section>' +
    '</div>';
  }

  /* ------------------------------------------------------- lista gestores */

  function viewGestores() {
    return '<div class="wrap">' +
      '<h1 class="lede">Os gestores</h1>' +
      '<p class="sub">Clique em qualquer carteira para ver posição por posição, movimentos do trimestre e saídas.</p>' +
      '<section class="section" style="margin-top:24px">' +
        '<div class="grid-gestores">' + D.gestores.map(cardGestor).join('') + '</div>' +
      '</section>' +
    '</div>';
  }

  /* --------------------------------------------------------- detalhe ----- */

  var ordenacao = { col: 'peso', dir: 'desc' };

  function tabelaPosicoes(g) {
    var linhas = g.posicoesDetalhe.slice();
    var dir = ordenacao.dir === 'asc' ? 1 : -1;

    linhas.sort(function (a, b) {
      var r;
      if (ordenacao.col === 'ticker') { r = a.t.localeCompare(b.t); }
      else if (ordenacao.col === 'empresa') { r = a.n.localeCompare(b.n, 'pt-BR'); }
      else if (ordenacao.col === 'setor') { r = a.s.localeCompare(b.s, 'pt-BR'); }
      else if (ordenacao.col === 'preco') {
        r = ((cot(a.t) || {}).p || -1) - ((cot(b.t) || {}).p || -1);
      }
      else if (ordenacao.col === 'varia') {
        var va = cot(a.t), vb = cot(b.t);
        r = ((va && va.var != null) ? va.var : -1e9) - ((vb && vb.var != null) ? vb.var : -1e9);
      }
      else { r = (a.p == null ? -1 : a.p) - (b.p == null ? -1 : b.p); }
      return r * dir;
    });

    var maxP = Math.max.apply(null, g.posicoesDetalhe.map(function (h) { return h.p || 0; }));

    var corpo = linhas.map(function (h, i) {
      var largura = h.p ? (h.p / maxP) * 100 : 0;
      return '<tr>' +
        '<td class="rank">' + (i + 1) + '</td>' +
        '<td>' + botaoTicker(h.t, h.cls) + '</td>' +
        '<td>' + esc(h.n) + ' ' + tagMov(h.mov) + '</td>' +
        '<td><span class="setor">' + esc(h.s) + '</span></td>' +
        '<td class="pesoc r"><span class="peso">' + pct(h.p) + '</span></td>' +
        '<td class="barc"><span class="minibar"><i style="width:' + largura.toFixed(1) + '%"></i></span></td>' +
        (COT ? '<td class="r"><span class="peso">' + preco(h.t) + '</span></td>' +
               '<td class="r">' + varBase(h.t) + '</td>' : '') +
        '<td>' + (h.v ? '<span class="peso">' + usd(h.v) + '</span>' : '<span class="setor">—</span>') + '</td>' +
      '</tr>';
    }).join('');

    var resto = g._resto > 0.01
      ? '<tr class="rest"><td class="rank"></td><td>—</td>' +
        '<td>Demais posições (' + Math.max(0, g.posicoes - g._comPeso) + (g.posicoesAprox ? ' aprox.' : '') + ')</td>' +
        '<td></td><td class="pesoc r"><span class="peso">' + pct(g._resto) + '</span></td>' +
        '<td class="barc"><span class="minibar"><i style="width:' + ((g._resto / maxP) * 100).toFixed(1) + '%;background:var(--bar-rest)"></i></span></td>' +
        (COT ? '<td></td><td></td>' : '') +
        '<td></td></tr>'
      : '';

    function th(col, rot, cls) {
      var ativo = ordenacao.col === col;
      return '<th class="sortable ' + (cls || '') + '" data-sort="' + col + '"' +
        (ativo ? ' aria-sort="' + (ordenacao.dir === 'asc' ? 'ascending' : 'descending') + '"' : '') + '>' +
        rot + (ativo ? (ordenacao.dir === 'asc' ? ' ↑' : ' ↓') : '') + '</th>';
    }

    return '<div class="tablewrap"><table class="holdings' + (COT ? ' holdings--cot' : '') + '">' +
      '<thead><tr>' +
      '<th></th>' + th('ticker', 'Ticker') + th('empresa', 'Empresa') + th('setor', 'Setor') +
      th('peso', 'Peso', 'r') + '<th></th>' +
      (COT ? th('preco', 'Preço', 'r') + th('varia', 'Δ desde ' + D.meta.dataBase.slice(0, 5), 'r') : '') +
      '<th>Valor</th>' +
      '</tr></thead><tbody>' + corpo + resto + '</tbody></table></div>';
  }

  function viewGestor(id) {
    var g = D.gestores.filter(function (x) { return x.id === id; })[0];
    if (!g) { return '<div class="wrap"><p class="empty">Gestor não encontrado.</p></div>'; }

    var movs = g.posicoesDetalhe.filter(function (h) { return h.mov; });

    var mesmaEmpresa = Object.keys(g._empresas).filter(function (k) {
      var c = consenso.filter(function (x) { return x.chave === k; })[0];
      return c && c.n > 1;
    });

    return '<div class="wrap">' +
      '<button class="back" data-goto="#/panorama">← Panorama</button>' +

      '<div class="ghead">' +
        '<span class="sigla">' + esc(g.sigla) + '</span>' +
        '<div class="ghead__txt">' +
          '<h1>' + esc(g.nome) + '</h1>' +
          '<div class="ghead__firm">' + esc(g.gestora) + '</div>' +
          '<div class="ghead__meta">' +
            '<span>' + esc(g.base) + '</span>' +
            '<span>na atividade desde ' + g.desde + '</span>' +
            '<span>13F de ' + esc(D.meta.dataBase) + '</span>' +
          '</div>' +
        '</div>' +
      '</div>' +

      '<div class="estilo"><span class="lema">“' + esc(g.lema) + '”</span>' + esc(g.estilo) + '</div>' +

      '<div class="gmetrics">' +
        '<div class="metric"><div class="metric__v">' + usd(g.valor, g.valorAprox) + '</div>' +
          '<div class="metric__l">Valor da carteira 13F</div></div>' +
        '<div class="metric"><div class="metric__v">' + (g.posicoesAprox ? '~' : '') + nf(g.posicoes, 0) + '</div>' +
          '<div class="metric__l">Posições no formulário</div>' +
          '<div class="metric__h">' + g._comPeso + ' com peso divulgado</div></div>' +
        '<div class="metric"><div class="metric__v">' + pct(g._top5, 1) + '</div>' +
          '<div class="metric__l">Peso das 5 maiores</div>' +
          '<div class="metric__h">' + (g._top5 > 70 ? 'concentração alta' : g._top5 > 40 ? 'concentração média' : 'carteira pulverizada') + '</div></div>' +
        '<div class="metric"><div class="metric__v">' + esc(g._maior.t) + '</div>' +
          '<div class="metric__l">Maior posição</div>' +
          '<div class="metric__h">' + esc(g._maior.n) + ' · ' + pct(g._maior.p, 1) + '</div></div>' +
        '<div class="metric"><div class="metric__v">' + mesmaEmpresa.length + '</div>' +
          '<div class="metric__l">Empresas em comum</div>' +
          '<div class="metric__h">também estão em outra carteira desta lista</div></div>' +
      '</div>' +

      '<section class="section">' +
        '<div class="section__head"><h2>Posições divulgadas</h2>' +
          '<p class="section__note">Clique no ticker para ver quem mais detém a mesma empresa. Cabeçalhos ordenam a tabela.' +
          (COT ? ' Preços: fechamento de ' + dataCotacao() + ', via ' + esc(COT.fonte) +
                 ' — a coluna Δ compara com o fechamento na data-base do 13F.' : '') +
          '</p></div>' +
        tabelaPosicoes(g) +
        (g.demaisNota ? '<div class="notecard" style="margin-top:12px">' + esc(g.demaisNota) + '</div>' : '') +
      '</section>' +

      (movs.length ? '<section class="section">' +
        '<div class="section__head"><h2>Movimentos do trimestre</h2></div>' +
        '<div class="movs">' + movs.map(function (h) {
          return '<div class="mov">' + tagMov(h.mov) + botaoTicker(h.t) +
            '<span>' + esc(h.n) + '</span>' +
            (h.movNota ? '<span class="mov__txt">' + esc(h.movNota) + '</span>' : '') + '</div>';
        }).join('') + '</div></section>' : '') +

      (g.saidas.length ? '<section class="section">' +
        '<div class="section__head"><h2>Saídas</h2>' +
          '<p class="section__note">Posições zeradas no trimestre — não constam mais do formulário.</p></div>' +
        '<div class="exits">' + g.saidas.map(function (s) {
          return '<div class="exit"><span class="exit__tk">' + esc(s.t) + '</span>' +
            '<span>' + esc(s.n) + '</span>' +
            '<span class="exit__nota">' + esc(s.nota) + '</span></div>';
        }).join('') + '</div></section>' : '') +

      (g.notaSetor ? '<div class="notecard" style="margin-top:28px">' + esc(g.notaSetor) + '</div>' : '') +
    '</div>';
  }

  /* --------------------------------------------------------- consenso ---- */

  var filtroConsenso = 'compartilhadas';

  function viewConsenso() {
    var lista = filtroConsenso === 'compartilhadas' ? compartilhadas : consenso;

    return '<div class="wrap">' +
      '<h1 class="lede">Consenso</h1>' +
      '<p class="sub">As ' + totalEmpresas + ' empresas que aparecem nas posições divulgadas dos oito gestores, ' +
      'ordenadas por quantos deles detêm a mesma tese. ' + compartilhadas.length + ' empresas estão em mais de uma carteira — ' +
      'o resto é convicção solitária, o que costuma ser exatamente o ponto.</p>' +

      '<div class="picker" style="margin-top:20px">' +
        '<button class="pick" data-filtro="compartilhadas" data-on="' + (filtroConsenso === 'compartilhadas' ? 1 : 0) + '">' +
          'Em duas ou mais carteiras (' + compartilhadas.length + ')</button>' +
        '<button class="pick" data-filtro="todas" data-on="' + (filtroConsenso === 'todas' ? 1 : 0) + '">' +
          'Todas as empresas (' + totalEmpresas + ')</button>' +
      '</div>' +

      '<div class="consensus">' +
        '<div class="crow crow--head"><span></span><span>Empresa</span><span>Gestores</span><span>Quem detém e com que peso</span></div>' +
        lista.map(function (c, i) { return linhaConsenso(c, i + 1); }).join('') +
      '</div>' +
    '</div>';
  }

  /* --------------------------------------------------------- comparar ---- */

  var selecionados = ['buffett', 'lilu', 'klarman', 'dorsey'];

  function viewComparar() {
    var gs = D.gestores.filter(function (g) { return selecionados.indexOf(g.id) >= 0; });

    var picker = '<div class="picker">' + D.gestores.map(function (g) {
      var on = selecionados.indexOf(g.id) >= 0;
      return '<label class="pick" data-on="' + (on ? 1 : 0) + '">' +
        '<input type="checkbox" data-cmp="' + g.id + '"' + (on ? ' checked' : '') + '>' +
        esc(g.nome) + '</label>';
    }).join('') + '</div>';

    var corpo;
    if (gs.length < 2) {
      corpo = '<div class="tablewrap"><p class="empty">Selecione ao menos dois gestores para montar a matriz.</p></div>';
    } else {
      var chaves = {};
      gs.forEach(function (g) { Object.keys(g._empresas).forEach(function (k) { chaves[k] = 1; }); });

      var linhas = Object.keys(chaves).map(function (k) {
        var ref = null, pesos = [], quantos = 0;
        gs.forEach(function (g) {
          var e = g._empresas[k];
          if (e) { ref = ref || e; quantos++; pesos.push(e.peso); } else { pesos.push(null); }
        });
        return { nome: ref.nome, setor: ref.setor, tickers: ref.tickers, pesos: pesos, quantos: quantos,
                 max: Math.max.apply(null, pesos.map(function (p) { return p || 0; })) };
      }).sort(function (a, b) { return (b.quantos - a.quantos) || (b.max - a.max) || a.nome.localeCompare(b.nome, 'pt-BR'); });

      var comuns = linhas.filter(function (l) { return l.quantos > 1; }).length;

      corpo =
        '<p class="section__note" style="margin-bottom:12px">' +
          (comuns
            ? comuns + (comuns === 1 ? ' empresa aparece' : ' empresas aparecem') + ' em mais de uma das carteiras selecionadas (marcadas na borda).'
            : 'Nenhuma empresa em comum entre as carteiras selecionadas.') +
        '</p>' +
        '<div class="tablewrap"><table class="matrix"><thead><tr>' +
          '<th>Empresa</th>' + gs.map(function (g) { return '<th>' + esc(g.curto) + '<br><span style="font-weight:400">' + esc(g.gestora.split(' ')[0]) + '</span></th>'; }).join('') +
        '</tr></thead><tbody>' +
        linhas.map(function (l) {
          return '<tr data-shared="' + (l.quantos > 1 ? 1 : 0) + '">' +
            '<td><b style="font-weight:500">' + esc(l.nome) + '</b><br>' +
              '<span class="crow__tk">' + l.tickers.map(esc).join(' · ') + '</span></td>' +
            l.pesos.map(function (p) {
              return p == null ? '<td class="zero">—</td>' : '<td><span class="cell-w">' + pct(p, 1) + '</span></td>';
            }).join('') +
          '</tr>';
        }).join('') +
        '</tbody></table></div>';
    }

    return '<div class="wrap">' +
      '<h1 class="lede">Comparar carteiras</h1>' +
      '<p class="sub">Matriz de pesos lado a lado. Serve para ver rápido onde teses coincidem e onde cada gestor está sozinho.</p>' +
      '<section class="section" style="margin-top:22px">' + picker + corpo + '</section>' +
    '</div>';
  }

  /* --------------------------------------------- painel "quem detém" ----- */

  var sheet, sheetBox;

  function abrirTicker(ticker) {
    var alvo = null;
    D.gestores.some(function (g) {
      return g.posicoesDetalhe.some(function (h) {
        if (h.t === ticker) { alvo = h; return true; }
        return false;
      });
    });
    if (!alvo) { return; }

    var c = consenso.filter(function (x) { return x.chave === chaveEmpresa(alvo.n); })[0];
    if (!c) { return; }

    var maxP = c.pesoMax || 1;

    sheetBox.innerHTML =
      '<div class="sheet__head">' +
        '<div><h3>' + esc(c.nome) + '</h3>' +
          '<div class="sheet__sub">' + c.tickersArr.map(esc).join(' · ') + ' · ' + esc(c.setor) + '</div></div>' +
        '<button class="sheet__x" data-fechar aria-label="Fechar">✕</button>' +
      '</div>' +
      (cot(alvo.t)
        ? '<div class="quote"><span class="quote__p">' + preco(alvo.t) + '</span>' +
          '<span class="quote__d">' + varBase(alvo.t) + ' desde ' + esc(D.meta.dataBase) + '</span>' +
          '<span class="quote__f">fechamento de ' + dataCotacao() + ' · ' + esc(COT.fonte) + '</span></div>'
        : '') +
      '<p class="sub" style="margin-top:14px;font-size:13px">' +
        (c.n > 1
          ? 'Detida por ' + c.n + ' dos ' + D.gestores.length + ' gestores acompanhados. Peso médio de ' + pct(c.pesoMedio, 1) + ' entre eles.'
          : 'Posição exclusiva de ' + c.donos[0].gestor.nome + ' nesta lista.') +
      '</p>' +
      '<ul class="holders">' + c.donos.map(function (d) {
        return '<li>' +
          '<span><span class="hname">' + esc(d.gestor.nome) + '</span>' + (d.mov ? ' ' + tagMov(d.mov) : '') +
            '<br><span class="hfirm">' + esc(d.gestor.gestora) + '</span></span>' +
          '<span class="minibar"><i style="width:' + ((d.peso / maxP) * 100).toFixed(1) + '%"></i></span>' +
          '<span class="peso" style="text-align:right">' + pct(d.peso, 1) + '</span>' +
        '</li>';
      }).join('') + '</ul>';

    sheet.hidden = false;
    var x = sheetBox.querySelector('[data-fechar]');
    if (x) { x.focus(); }
  }

  function fecharSheet() { sheet.hidden = true; }

  /* ------------------------------------------------------------- busca --- */

  var indice = (function () {
    var itens = [];
    D.gestores.forEach(function (g) {
      itens.push({ tipo: 'gestor', rotulo: g.nome, extra: g.gestora, href: '#/g/' + g.id, tk: g.sigla });
    });
    consenso.forEach(function (c) {
      itens.push({ tipo: 'empresa', rotulo: c.nome, extra: c.n + (c.n === 1 ? ' gestor' : ' gestores'),
                   ticker: c.tickersArr[0], tk: c.tickersArr.join(' · ') });
    });
    return itens;
  })();

  function buscar(q) {
    var t = q.trim().toLowerCase();
    if (!t) { return []; }
    return indice.filter(function (it) {
      return (it.rotulo + ' ' + it.tk + ' ' + (it.extra || '')).toLowerCase().indexOf(t) >= 0;
    }).slice(0, 10);
  }

  function pintarBusca(q) {
    var pop = $('#buscaPop');
    var res = buscar(q);
    if (!q.trim()) { pop.hidden = true; pop.innerHTML = ''; return; }
    if (!res.length) {
      pop.hidden = false;
      pop.innerHTML = '<p class="search__empty">Nada encontrado para “' + esc(q) + '”.</p>';
      return;
    }
    pop.hidden = false;
    pop.innerHTML = res.map(function (it) {
      var attr = it.href ? 'data-goto="' + it.href + '"' : 'data-tk="' + esc(it.ticker) + '"';
      return '<button class="search__item" ' + attr + '>' +
        '<span class="tk">' + esc(it.tk) + '</span>' +
        '<span>' + esc(it.rotulo) + '</span>' +
        '<span class="cap">' + esc(it.extra) + '</span></button>';
    }).join('');
  }

  /* ------------------------------------------------------------ rotas ---- */

  var app;

  function rota() {
    var h = location.hash || '#/panorama';
    var m = h.match(/^#\/g\/([\w-]+)$/);
    if (m) { return { v: 'gestor', id: m[1] }; }
    if (h === '#/gestores') { return { v: 'gestores' }; }
    if (h === '#/consenso') { return { v: 'consenso' }; }
    if (h === '#/comparar') { return { v: 'comparar' }; }
    return { v: 'panorama' };
  }

  function pintar(manterScroll) {
    var r = rota();
    var y = window.scrollY;

    if (r.v === 'gestor') { app.innerHTML = viewGestor(r.id); }
    else if (r.v === 'gestores') { app.innerHTML = viewGestores(); }
    else if (r.v === 'consenso') { app.innerHTML = viewConsenso(); }
    else if (r.v === 'comparar') { app.innerHTML = viewComparar(); }
    else { app.innerHTML = viewPanorama(); }

    var aba = r.v === 'gestor' ? 'gestores' : r.v;
    $$('.tab').forEach(function (t) {
      t.setAttribute('aria-selected', String(t.dataset.tab === aba));
    });

    if (manterScroll) { window.scrollTo(0, y); } else { window.scrollTo(0, 0); }
  }

  /* --------------------------------------------------------------- tema -- */

  function lerTema() {
    try { return localStorage.getItem('cc-tema'); } catch (e) { return null; }
  }
  function salvarTema(v) {
    try { localStorage.setItem('cc-tema', v); } catch (e) { /* modo privado */ }
  }
  function aplicarTema(v) {
    if (v === 'dark' || v === 'light') { document.documentElement.setAttribute('data-theme', v); }
    else { document.documentElement.removeAttribute('data-theme'); }
  }

  /* --------------------------------------------------------------- init -- */

  function init() {
    app = $('#app');
    sheet = $('#sheet');
    sheetBox = $('#sheetBox');

    aplicarTema(lerTema());

    // rodapé: fontes + selo de atualização
    var fontes = $('#fontes');
    if (fontes) {
      fontes.innerHTML = D.fontes.map(function (f) {
        return '<li><a href="' + esc(f.url) + '" target="_blank" rel="noopener noreferrer">' + esc(f.nome) + '</a></li>';
      }).join('');
    }
    $$('[data-competencia]').forEach(function (el) { el.textContent = D.meta.competencia; });
    var selo = $('#seloCotacoes');
    if (selo) {
      selo.innerHTML = COT
        ? 'Cotações: fechamento de <strong>' + dataCotacao() + '</strong> via ' + esc(COT.fonte) +
          '. A coluna Δ compara esse fechamento com o da data-base do 13F (' + esc(D.meta.dataBase) + '), ' +
          'ou seja, quanto o papel andou desde o trimestre reportado.' +
          (COT.semDados && COT.semDados.length
            ? ' Sem cotação disponível para ' + COT.semDados.map(esc).join(', ') + '.'
            : '')
        : 'Nenhuma cotação carregada nesta versão — a tabela mostra só os pesos do 13F. ' +
          'Na cópia local, <span class="num">python atualizar_cotacoes.py</span> gera ' +
          '<span class="num">data/cotacoes.js</span> e liga as colunas de preço e variação.';
    }
    $$('[data-atualizado]').forEach(function (el) { el.textContent = D.meta.atualizado; });

    window.addEventListener('hashchange', function () { pintar(false); });
    pintar(false);

    // um único delegador de cliques para toda a página
    document.addEventListener('click', function (ev) {
      var el = ev.target.closest('[data-goto],[data-tk],[data-sort],[data-filtro],[data-fechar],[data-tema]');
      if (!el) { return; }

      if (el.hasAttribute('data-goto')) {
        ev.preventDefault();
        var alvo = el.getAttribute('data-goto');
        $('#buscaPop').hidden = true;
        $('#busca').value = '';
        fecharSheet();
        if (location.hash === alvo) { pintar(false); } else { location.hash = alvo; }
        return;
      }
      if (el.hasAttribute('data-tk')) {
        ev.preventDefault();
        $('#buscaPop').hidden = true;
        abrirTicker(el.getAttribute('data-tk'));
        return;
      }
      if (el.hasAttribute('data-sort')) {
        var col = el.getAttribute('data-sort');
        if (ordenacao.col === col) { ordenacao.dir = ordenacao.dir === 'asc' ? 'desc' : 'asc'; }
        else { ordenacao.col = col; ordenacao.dir = col === 'peso' ? 'desc' : 'asc'; }
        pintar(true);
        return;
      }
      if (el.hasAttribute('data-filtro')) {
        filtroConsenso = el.getAttribute('data-filtro');
        pintar(true);
        return;
      }
      if (el.hasAttribute('data-fechar')) { fecharSheet(); return; }
      if (el.hasAttribute('data-tema')) {
        var atual = document.documentElement.getAttribute('data-theme');
        var escuroDoSistema = window.matchMedia('(prefers-color-scheme: dark)').matches;
        var novo = atual ? (atual === 'dark' ? 'light' : 'dark') : (escuroDoSistema ? 'light' : 'dark');
        aplicarTema(novo); salvarTema(novo);
      }
    });

    // seleção de gestores na vista Comparar
    document.addEventListener('change', function (ev) {
      var cb = ev.target.closest('[data-cmp]');
      if (!cb) { return; }
      var id = cb.getAttribute('data-cmp');
      if (cb.checked) { if (selecionados.indexOf(id) < 0) { selecionados.push(id); } }
      else { selecionados = selecionados.filter(function (x) { return x !== id; }); }
      pintar(true);
    });

    // busca
    var busca = $('#busca');
    busca.addEventListener('input', function () { pintarBusca(busca.value); });
    busca.addEventListener('keydown', function (ev) {
      if (ev.key === 'Escape') { busca.value = ''; pintarBusca(''); busca.blur(); }
      if (ev.key === 'Enter') {
        var primeiro = $('#buscaPop .search__item');
        if (primeiro) { primeiro.click(); }
      }
    });

    document.addEventListener('click', function (ev) {
      if (!ev.target.closest('.search')) { $('#buscaPop').hidden = true; }
    });

    // fecha o painel ao clicar fora ou com Esc
    sheet.addEventListener('click', function (ev) { if (ev.target === sheet) { fecharSheet(); } });
    document.addEventListener('keydown', function (ev) {
      if (ev.key === 'Escape' && !sheet.hidden) { fecharSheet(); }
      if (ev.key === '/' && document.activeElement !== busca) { ev.preventDefault(); busca.focus(); }
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
