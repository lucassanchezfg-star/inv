#!/usr/bin/env python3
"""
Atualiza as cotações usadas pelo site.

Lê os tickers de data/carteiras.js, busca no Stooq (CSV público, sem cadastro):
  • a cotação de fechamento mais recente;
  • o fechamento na data-base do 13F (meta.dataBase), para calcular a variação
    desde o trimestre reportado.
Grava tudo em data/cotacoes.js e, com --build, regenera dist/index.html.

Uso:
    python atualizar_cotacoes.py
    python atualizar_cotacoes.py --build          # já regenera o arquivo único
    python atualizar_cotacoes.py --so AAPL,KO     # apenas alguns tickers

Só usa a biblioteca padrão. Se um ticker não existir no Stooq, ele é listado no
fim da execução e simplesmente não recebe preço no site — nada é estimado.

Trocar de provedor: implemente as duas funções de `PROVEDOR_STOOQ` num dicionário
igual e passe --provedor <nome>. O resto do script não muda.
"""

from __future__ import annotations

import argparse
import csv
import io
import json
import re
import subprocess
import sys
import time
import urllib.error
import urllib.request
from datetime import date, datetime, timedelta
from pathlib import Path

RAIZ = Path(__file__).resolve().parent
CARTEIRAS = RAIZ / "data" / "carteiras.js"
SAIDA = RAIZ / "data" / "cotacoes.js"

UA = "Mozilla/5.0 (compatible; circulo-de-competencia/1.0)"
PAUSA = 0.35  # segundos entre requisições históricas, para não martelar o servidor


# --------------------------------------------------------------------- leitura


def ler_carteiras() -> tuple[list[str], str]:
    """Devolve (tickers, data-base ISO) lidos de data/carteiras.js."""
    if not CARTEIRAS.exists():
        sys.exit("data/carteiras.js não encontrado — rode a partir da raiz do projeto.")
    src = io.open(CARTEIRAS, encoding="utf-8").read()

    # só as posições em carteira; 'saidas' não interessa aqui
    tickers: list[str] = []
    for bloco in re.findall(r"posicoesDetalhe: \[(.*?)\n      \],", src, re.S):
        for t in re.findall(r"\{ t: '([^']+)'", bloco):
            if t not in tickers:
                tickers.append(t)

    m = re.search(r"dataBase: '(\d{2})/(\d{2})/(\d{4})'", src)
    if not m:
        sys.exit("meta.dataBase não encontrado em data/carteiras.js.")
    base = "%s-%s-%s" % (m.group(3), m.group(2), m.group(1))

    return tickers, base


# -------------------------------------------------------------------- provedor


def simbolo_stooq(ticker: str) -> str:
    """AAPL -> aapl.us | BRK.B -> brk-b.us"""
    return ticker.lower().replace(".", "-") + ".us"


def http(url: str, tentativas: int = 3) -> str:
    erro = None
    for i in range(tentativas):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": UA})
            with urllib.request.urlopen(req, timeout=25) as r:
                return r.read().decode("utf-8", "replace")
        except (urllib.error.URLError, TimeoutError, OSError) as e:
            erro = e
            time.sleep(1.2 * (i + 1))
    raise RuntimeError("falha ao buscar %s (%s)" % (url, erro))


def stooq_ultimos(tickers: list[str]) -> dict[str, dict]:
    """Cotação mais recente. O Stooq aceita vários símbolos separados por '+'."""
    out: dict[str, dict] = {}
    LOTE = 20
    for i in range(0, len(tickers), LOTE):
        lote = tickers[i : i + LOTE]
        alvo = "+".join(simbolo_stooq(t) for t in lote)
        url = "https://stooq.com/q/l/?s=%s&f=sd2t2ohlcv&h&e=csv" % alvo
        texto = http(url)
        por_simbolo = {simbolo_stooq(t): t for t in lote}
        for linha in csv.DictReader(io.StringIO(texto)):
            sym = (linha.get("Symbol") or "").strip().lower()
            tk = por_simbolo.get(sym)
            fech = (linha.get("Close") or "").strip()
            if not tk or fech in ("", "N/D"):
                continue
            try:
                out[tk] = {"p": float(fech), "d": (linha.get("Date") or "").strip()}
            except ValueError:
                continue
        time.sleep(PAUSA)
    return out


def stooq_fechamento_em(ticker: str, iso: str) -> float | None:
    """Fechamento na data-base. Pega a janela dos 7 dias anteriores e usa a
    última sessão <= data-base, para atravessar feriado e fim de semana."""
    alvo = date.fromisoformat(iso)
    d1 = (alvo - timedelta(days=7)).strftime("%Y%m%d")
    d2 = alvo.strftime("%Y%m%d")
    url = "https://stooq.com/q/d/l/?s=%s&d1=%s&d2=%s&i=d" % (simbolo_stooq(ticker), d1, d2)
    try:
        texto = http(url)
    except RuntimeError:
        return None
    linhas = [l for l in csv.DictReader(io.StringIO(texto)) if (l.get("Close") or "").strip()]
    if not linhas:
        return None
    try:
        return float(linhas[-1]["Close"])
    except (ValueError, KeyError):
        return None


PROVEDORES = {
    "stooq": {"nome": "Stooq", "ultimos": stooq_ultimos, "historico": stooq_fechamento_em},
}


# ---------------------------------------------------------------------- escrita


def escrever(precos: dict[str, dict], base: str, fonte: str, faltando: list[str]) -> None:
    cab = (
        "/* Gerado por atualizar_cotacoes.py — NÃO edite à mão.\n"
        "   Fonte: %s. Fechamentos, não tempo real.\n"
        "   `base` é o fechamento na data-base do 13F; `var` é a variação %% até `p`.\n"
        "   Ticker sem preço simplesmente não aparece aqui — o site esconde a coluna. */\n\n"
    ) % fonte

    corpo = {
        "atualizado": datetime.now().astimezone().isoformat(timespec="seconds"),
        "fonte": fonte,
        "dataBase": base,
        "semDados": faltando,
        "precos": precos,
    }
    SAIDA.parent.mkdir(parents=True, exist_ok=True)
    io.open(SAIDA, "w", encoding="utf-8", newline="\n").write(
        cab + "window.COTACOES = " + json.dumps(corpo, ensure_ascii=False, indent=2) + ";\n"
    )


# ------------------------------------------------------------------------ main


def main() -> None:
    ap = argparse.ArgumentParser(description="Atualiza data/cotacoes.js")
    ap.add_argument("--provedor", default="stooq", choices=sorted(PROVEDORES))
    ap.add_argument("--so", help="lista de tickers separados por vírgula")
    ap.add_argument("--build", action="store_true", help="roda build.py no fim")
    ap.add_argument("--sem-historico", action="store_true",
                    help="não busca o fechamento da data-base (bem mais rápido)")
    args = ap.parse_args()

    prov = PROVEDORES[args.provedor]
    tickers, base = ler_carteiras()

    if args.so:
        filtro = {t.strip().upper() for t in args.so.split(",") if t.strip()}
        tickers = [t for t in tickers if t.upper() in filtro]
        if not tickers:
            sys.exit("nenhum dos tickers pedidos está nas carteiras.")

    print("%d tickers · data-base do 13F: %s · fonte: %s" % (len(tickers), base, prov["nome"]))

    print("buscando cotações...", flush=True)
    try:
        precos = prov["ultimos"](tickers)
    except RuntimeError as e:
        sys.exit("erro de rede: %s" % e)
    print("  %d de %d com preço" % (len(precos), len(tickers)))

    if not args.sem_historico:
        print("buscando fechamento em %s (1 requisição por ticker)..." % base, flush=True)
        for i, tk in enumerate(sorted(precos), 1):
            fech = prov["historico"](tk, base)
            if fech:
                precos[tk]["base"] = fech
                if fech:
                    precos[tk]["var"] = round((precos[tk]["p"] / fech - 1) * 100, 2)
            sys.stdout.write("\r  %d/%d" % (i, len(precos)))
            sys.stdout.flush()
            time.sleep(PAUSA)
        print()

    faltando = sorted(set(tickers) - set(precos))
    escrever(precos, base, prov["nome"], faltando)
    print("data/cotacoes.js gravado.")

    if faltando:
        print("\nsem cotação (ficam sem preço no site, nada foi estimado):")
        print("  " + ", ".join(faltando))

    com_var = [t for t in precos if "var" in precos[t]]
    if com_var:
        piores = sorted(com_var, key=lambda t: precos[t]["var"])
        print("\nvariação desde %s — extremos:" % base)
        for tk in piores[:3] + piores[-3:][::-1]:
            print("  %-6s %+8.2f%%   %8.2f -> %8.2f" %
                  (tk, precos[tk]["var"], precos[tk]["base"], precos[tk]["p"]))

    if args.build:
        print()
        subprocess.run([sys.executable, str(RAIZ / "build.py")], check=True)


if __name__ == "__main__":
    main()
