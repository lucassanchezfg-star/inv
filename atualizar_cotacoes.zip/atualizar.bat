@echo off
rem Atualiza as cotacoes e regenera dist/index.html.
rem Usado pelo Agendador de Tarefas do Windows (ver README).
cd /d "%~dp0"
python atualizar_cotacoes.py --build
if errorlevel 1 (
  echo.
  echo FALHOU. Verifique conexao com a internet e se "python" esta no PATH.
  exit /b 1
)
