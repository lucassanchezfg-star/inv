/* Placeholder. Rode `python atualizar_cotacoes.py` para preencher este arquivo
   com as cotações reais — ele será sobrescrito por completo.
   Enquanto estiver null, o site simplesmente não mostra as colunas de preço. */

window.COTACOES = null;
