# Círculo de Competência

Acompanhamento das carteiras 13F de oito investidores em valor. A ideia é a mesma do
[Dataroma](https://www.dataroma.com/m/home.php) — ver o que os grandes alocadores têm na mão —
com quatro coisas que o Dataroma não entrega bem:

1. **Sobreposição em primeiro plano.** A vista *Consenso* lista cada empresa pelo número de
   gestores que a detêm e mostra o peso de cada um lado a lado. Classes diferentes da mesma
   empresa (Alphabet A e C) entram somadas.
2. **Métricas de concentração.** Peso das cinco maiores, número de posições com peso divulgado
   e leitura qualitativa ("concentração alta" / "carteira pulverizada"). É o que separa Pabrai
   (4 nomes) da First Eagle (~424).
3. **Comparação lado a lado.** A vista *Comparar* monta uma matriz de pesos entre 2 e 8 gestores,
   destacando as linhas em que mais de um deles detém a mesma empresa.
4. **Interface em português, responsiva e com tema claro/escuro.** Busca global por gestor,
   empresa ou ticker (atalho `/`); qualquer ticker clicado abre um painel com todos os gestores
   que detêm aquela empresa.

Site estático, sem framework e sem dependências em runtime. Roteamento por hash (`#/consenso`),
o que evita qualquer necessidade de *rewrite* no servidor.

## Gestores acompanhados

| Gestor | Gestora | Carteira 13F | Posições |
|---|---|---:|---:|
| Warren Buffett | Berkshire Hathaway | US$ 299,3 bi | 29 |
| First Eagle | First Eagle Investment Management | US$ 59,9 bi | ~424 |
| Bill Ackman | Pershing Square Capital | US$ 19,5 bi | 14 |
| Seth Klarman | The Baupost Group | US$ 5,4 bi | 23 |
| Li Lu | Himalaya Capital Management | US$ 3,7 bi | ~6 |
| Prem Watsa | Fairfax Financial Holdings | ~US$ 3,0 bi | 32 |
| Pat Dorsey | Dorsey Asset Management | US$ 1,6 bi | 11 |
| Mohnish Pabrai | Pabrai Investment Funds | US$ 326,7 mi | 4 |

Competência: **30/06/2026** (2º trimestre de 2026), protocolos de meados de agosto de 2026.

## Publicar (GitHub Pages)

O deploy é por `git push` — nenhum CLI de hospedagem, nenhum Node.

### 1. Subir o repositório

Crie um repositório vazio no GitHub (sem README, sem .gitignore) e:

```bash
git remote add origin https://github.com/SEU-USUARIO/circulo-de-competencia.git
git branch -M main
git push -u origin main
```

### 2. Ligar o Pages

Em **Settings → Pages**, no campo *Source*, escolha **GitHub Actions**. Não escolha
"Deploy from a branch" — o workflow deste repositório publica via Actions justamente para poder
buscar as cotações antes de subir.

Pronto: o site sai em `https://SEU-USUARIO.github.io/circulo-de-competencia/`.

### 3. Domínio próprio

Em **Settings → Secrets and variables → Actions → Variables**, crie uma variável chamada
`DOMINIO` com o host desejado, por exemplo `carteiras.seudominio.com.br`. O workflow escreve o
arquivo `CNAME` a partir dela; sem a variável, o site continua na URL padrão e nada quebra.

No DNS do domínio, para um **subdomínio**, um registro CNAME:

```
carteiras    CNAME    SEU-USUARIO.github.io.
```

Para o **domínio raiz**, quatro registros A apontando para o Pages:

```
@    A    185.199.108.153
@    A    185.199.109.153
@    A    185.199.110.153
@    A    185.199.111.153
```

Depois volte em **Settings → Pages → Custom domain**, informe o mesmo host e marque
**Enforce HTTPS** (o certificado leva alguns minutos para ser emitido).

## Cotações

Os pesos do 13F são fotografia de 30/06/2026. As cotações vêm por fora, do **Stooq** — CSV
público, sem cadastro e sem chave de API. Duas colunas aparecem na tabela: **Preço** e
**Δ desde 30/06**, a variação entre o fechamento na data-base do 13F e o fechamento mais
recente. Esse Δ é o número que interessa: quanto o papel andou desde o trimestre em que o gestor
estava naquela posição.

**No site publicado, isso é automático.** O workflow `.github/workflows/site.yml` roda de terça a
sábado às 8h de Brasília, busca as cotações no runner do GitHub e publica. Seu computador não
precisa estar ligado, e nada é commitado de volta — o repositório fica só com o código.

Se o Stooq não responder, o workflow emite um *warning*, recupera do cache o último arquivo bom e
publica com as cotações anteriores em vez de falhar. Ticker que o Stooq não tiver fica sem preço e
é listado no rodapé do site — **nada é estimado**.

Para rodar na sua máquina:

```bash
python atualizar_cotacoes.py --build
```

| | |
|---|---|
| `--build` | também regenera `dist/index.html` |
| `--so AAPL,KO` | atualiza só alguns tickers |
| `--sem-historico` | pula o fechamento da data-base (1 requisição em vez de 46) |
| `--provedor stooq` | provedor de cotação (só Stooq implementado; ver docstring para plugar outro) |

`data/cotacoes.js` é gerado. O repositório carrega apenas um placeholder com
`window.COTACOES = null` — enquanto estiver assim, as colunas de preço simplesmente não aparecem.
Rodar o script localmente deixa o arquivo como modificado no `git status`; commitar ou descartar
(`git checkout -- data/cotacoes.js`) dá no mesmo, porque o workflow sobrescreve na publicação.

## Rodar localmente

Não há build nem dependências. Abra `index.html` no navegador — os dados vêm de `<script>`
comum, não de `fetch`, então funciona por `file://` com duplo clique. Ou sirva:

```bash
python -m http.server 8000
```

## Versão de arquivo único

`dist/index.html` é a página inteira com CSS, dados e JS embutidos. Serve para publicar como
Artifact do Claude ou mandar por e-mail — **não** é o que vai para o site, que usa os arquivos
separados.

```bash
python build.py
```

## Estrutura

```
index.html                    marcação estática (cabeçalho, abas, painel, rodapé)
assets/style.css              tokens de tema em :root + componentes
assets/app.js                 rotas por hash, vistas, consenso, comparação, busca
data/carteiras.js             ÚNICO arquivo a editar para atualizar um trimestre
data/cotacoes.js              GERADO — não edite à mão
atualizar_cotacoes.py         busca cotações no Stooq e grava data/cotacoes.js
atualizar.bat                 wrapper para o Agendador de Tarefas do Windows
build.py                      gera dist/index.html (arquivo único)
.github/workflows/site.yml    cotações + publicação no GitHub Pages
```

## Atualizar para o próximo trimestre

Tudo mora em `data/carteiras.js`. O cabeçalho do arquivo documenta o formato; em resumo:

- `meta.competencia`, `meta.dataBase`, `meta.atualizado` — o selo e o rodapé leem daqui.
- Em cada gestor: `valor`, `posicoes` e a lista `posicoesDetalhe`.
- Cada posição: `t` (ticker), `n` (**nome da empresa — é a chave de agrupamento do Consenso**),
  `s` (setor), `p` (peso em %), e opcionalmente `cls`, `v`, `mov` (`novo` / `add` / `trim`) e
  `movNota`.
- `saidas` recebe as posições zeradas no trimestre.

A linha "Demais posições" é calculada (`100% − soma dos pesos listados`), então não precisa ser
escrita à mão. Peso que a fonte não divulgou vai como `p: null` e aparece como `n/d` — nunca
estime. Um `git push` publica.

## Limites do 13F

O formulário 13F-HR cobre **apenas ações listadas nos EUA**, é entregue com até 45 dias de atraso
e não revela posições vendidas. Caixa, títulos públicos, imóveis, participações em empresas
fechadas e posições em bolsas estrangeiras ficam de fora — o que é especialmente distorcivo para
Berkshire (dezenas de operações integrais), Fairfax (seguradora) e Baupost (histórico de caixa
alto). Trate como mapa de convicção, não como retrato de patrimônio.

## Fontes

SEC EDGAR (13F-HR), Dataroma, GuruFocus, ValueSider, WhaleWisdom, Acquirer's Multiple, 13f.info.

Site de estudo. Não é recomendação de investimento.
