/* =============================================================================
   Círculo de Competência — base de dados
   -----------------------------------------------------------------------------
   Fonte: formulários 13F-HR entregues à SEC, competência 30/06/2026
   (protocolados em meados de agosto de 2026), compilados a partir de
   agregadores públicos (GuruFocus, Dataroma, ValueSider, WhaleWisdom,
   Acquirer's Multiple, Seeking Alpha).

   IMPORTANTE — leia antes de editar:
   • `p` é o peso em % do portfólio 13F do gestor (não do patrimônio total).
   • Um 13F cobre apenas ações listadas nos EUA. Caixa, títulos, participações
     em empresas fechadas e ativos fora dos EUA NÃO aparecem.
   • Quando só o topo da carteira foi divulgado pelas fontes, as demais
     posições entram agregadas na linha "Demais posições" calculada
     automaticamente (100% − soma dos pesos listados).
   • `n` é o nome da EMPRESA e serve de chave de agrupamento no Consenso.
     Classes diferentes da mesma empresa (Alphabet A e C) usam o mesmo `n`
     e se diferenciam por `cls`.
   • `mov`: 'novo' | 'add' | 'trim' | null
   ========================================================================== */

window.DADOS = {
  meta: {
    competencia: '2º trimestre de 2026',
    dataBase: '30/06/2026',
    protocolo: 'meados de agosto de 2026',
    atualizado: '04/09/2026',
  },

  setores: [
    'Tecnologia',
    'Financeiro',
    'Comunicação',
    'Consumo discricionário',
    'Consumo básico',
    'Saúde',
    'Energia',
    'Materiais',
    'Industrial',
    'Imobiliário',
  ],

  gestores: [
    /* ---------------------------------------------------------------- */
    {
      id: 'buffett',
      nome: 'Warren Buffett',
      curto: 'Buffett',
      gestora: 'Berkshire Hathaway',
      sigla: 'WB',
      base: 'Omaha, EUA',
      desde: 1965,
      lema: 'Negócio excelente a preço razoável, para sempre',
      estilo:
        'Compra fluxo de caixa previsível com marca forte e o mantém por décadas. ' +
        'A carteira 13F é só a ponta visível: a Berkshire também carrega dezenas de ' +
        'operações integrais (seguros, ferrovia, energia) e uma montanha de Treasuries.',
      valor: 299_300_000_000,
      posicoes: 29,
      posicoesAprox: false,
      notaSetor: 'Serviços financeiros respondem por 34,6% da carteira.',
      posicoesDetalhe: [
        { t: 'AAPL',  n: 'Apple',              s: 'Tecnologia',             p: 22.04, v: 65_950_000_000 },
        { t: 'AXP',   n: 'American Express',   s: 'Financeiro',             p: 17.14, v: 51_280_000_000 },
        { t: 'KO',    n: 'Coca-Cola',          s: 'Consumo básico',         p: 10.86, v: 32_510_000_000 },
        { t: 'GOOGL', n: 'Alphabet',           s: 'Comunicação',            p:  9.41, v: 28_160_000_000, cls: 'Classe A', mov: 'add', movNota: 'compra relevante no trimestre (~US$ 7,9 bi)' },
        { t: 'BAC',   n: 'Bank of America',    s: 'Financeiro',             p:  9.20, v: 27_540_000_000 },
        { t: 'CVX',   n: 'Chevron',            s: 'Energia',                p:  4.67, v: 13_990_000_000 },
        { t: 'OXY',   n: 'Occidental Petroleum', s: 'Energia',              p:  4.30, v: 12_870_000_000 },
        { t: 'CB',    n: 'Chubb',              s: 'Financeiro',             p:  3.90, v: 11_670_000_000 },
        { t: 'MCO',   n: "Moody's",            s: 'Financeiro',             p:  3.73, v: 11_170_000_000 },
        { t: 'KHC',   n: 'Kraft Heinz',        s: 'Consumo básico',         p:  2.57, v:  7_690_000_000 },
      ],
      demaisNota:
        'As 19 posições restantes incluem Delta Air Lines, Sirius XM, VeriSign, Kroger, ' +
        'Ally Financial, Lennar, Liberty Live, New York Times e Capital One.',
      saidas: [],
    },

    /* ---------------------------------------------------------------- */
    {
      id: 'ackman',
      nome: 'Bill Ackman',
      curto: 'Ackman',
      gestora: 'Pershing Square Capital',
      sigla: 'BA',
      base: 'Nova York, EUA',
      desde: 2004,
      lema: 'Poucas apostas, grandes, e voz ativa na mesa',
      estilo:
        'Concentra em 10 a 15 nomes de qualidade e, quando julga necessário, ' +
        'atua como acionista ativista para destravar valor. Trimestre de reciclagem ' +
        'pesada: saiu de Alphabet e Universal Music e entrou nas quatro "máquinas de pedágio" ' +
        'do sistema financeiro e da mídia.',
      valor: 19_470_000_000,
      posicoes: 14,
      posicoesAprox: false,
      posicoesDetalhe: [
        { t: 'UBER', n: 'Uber Technologies',        s: 'Tecnologia',             p: 12.70 },
        { t: 'BN',   n: 'Brookfield',               s: 'Financeiro',             p: 12.60 },
        { t: 'MSFT', n: 'Microsoft',                s: 'Tecnologia',             p: 11.90 },
        { t: 'AMZN', n: 'Amazon',                   s: 'Consumo discricionário', p: 10.50, mov: 'trim', movNota: 'redução de 25% na posição' },
        { t: 'HHH',  n: 'Howard Hughes Holdings',   s: 'Imobiliário',            p: 10.20 },
        { t: 'QSR',  n: 'Restaurant Brands',        s: 'Consumo discricionário', p:  9.60 },
        { t: 'META', n: 'Meta Platforms',           s: 'Comunicação',            p:  9.20 },
        { t: 'V',    n: 'Visa',                     s: 'Financeiro',             p:  5.80, mov: 'novo' },
        { t: 'MA',   n: 'Mastercard',               s: 'Financeiro',             p:  5.60, mov: 'novo' },
        { t: 'SPGI', n: 'S&P Global',               s: 'Financeiro',             p:  5.40, mov: 'novo' },
        { t: 'NFLX', n: 'Netflix',                  s: 'Comunicação',            p:  null, mov: 'novo' },
      ],
      demaisNota: 'Netflix entrou no trimestre; o peso exato não foi divulgado pelas fontes consultadas.',
      saidas: [
        { t: 'GOOGL', n: 'Alphabet', nota: 'posição zerada' },
        { t: 'UMG',   n: 'Universal Music Group', nota: 'vendida após proposta de aquisição rejeitada' },
      ],
    },

    /* ---------------------------------------------------------------- */
    {
      id: 'pabrai',
      nome: 'Mohnish Pabrai',
      curto: 'Pabrai',
      gestora: 'Pabrai Investment Funds',
      sigla: 'MP',
      base: 'Irvine, EUA',
      desde: 1999,
      lema: 'Cara e coroa: cara eu ganho muito, coroa eu perco pouco',
      estilo:
        'Clonagem declarada de Buffett e Munger levada ao extremo da concentração: ' +
        'três ou quatro nomes cíclicos, pequenos e fora de moda. A carteira 13F atual é ' +
        'praticamente uma aposta binária em carvão metalúrgico e sondas offshore.',
      valor: 326_749_000,
      posicoes: 4,
      posicoesAprox: false,
      posicoesDetalhe: [
        { t: 'HCC',  n: 'Warrior Met Coal',              s: 'Materiais',  p: 43.32 },
        { t: 'RIG',  n: 'Transocean',                    s: 'Energia',    p: 30.53 },
        { t: 'AMR',  n: 'Alpha Metallurgical Resources',  s: 'Materiais',  p: 26.11 },
        { t: 'KSPI', n: 'Kaspi.kz',                      s: 'Financeiro', p:  0.05 },
      ],
      demaisNota: null,
      saidas: [],
    },

    /* ---------------------------------------------------------------- */
    {
      id: 'watsa',
      nome: 'Prem Watsa',
      curto: 'Watsa',
      gestora: 'Fairfax Financial Holdings',
      sigla: 'PW',
      base: 'Toronto, Canadá',
      desde: 1985,
      lema: 'Deep value com hedge macro',
      estilo:
        'O "Buffett canadense" opera a partir do float de uma seguradora e aceita ' +
        'ficar anos errado enquanto espera a tese virar. Trimestre marcado por ' +
        'concentração agressiva em ouro e saída do petróleo.',
      valor: 3_000_000_000,
      valorAprox: true,
      posicoes: 32,
      posicoesAprox: false,
      posicoesDetalhe: [
        { t: 'ORLA', n: 'Orla Mining',    s: 'Materiais',              p: 21.55 },
        { t: 'EGO',  n: 'Eldorado Gold',  s: 'Materiais',              p: 16.18 },
        { t: 'KHC',  n: 'Kraft Heinz',    s: 'Consumo básico',         p: 12.80 },
        { t: 'UAA',  n: 'Under Armour',   s: 'Consumo discricionário', p: 10.98, mov: 'add', movNota: 'aumento substancial no trimestre' },
        { t: 'CVS',  n: 'CVS Health',     s: 'Saúde',                  p: 10.63 },
      ],
      demaisNota:
        'As 27 posições restantes não tiveram peso individual divulgado. ' +
        'Foram 6 posições novas no trimestre, entre elas Wendy’s.',
      saidas: [
        { t: 'OXY', n: 'Occidental Petroleum', nota: 'saída integral — era uma das maiores posições' },
      ],
    },

    /* ---------------------------------------------------------------- */
    {
      id: 'firsteagle',
      nome: 'First Eagle',
      curto: 'First Eagle',
      gestora: 'First Eagle Investment Management',
      sigla: 'FE',
      base: 'Nova York, EUA',
      desde: 1864,
      lema: 'Margem de segurança acima de tudo, inclusive do retorno',
      estilo:
        'Herdeira da escola Jean-Marie Eveillard: valor global, aversão a ' +
        'alavancagem e uma alocação estrutural em ouro como seguro. Carteira ' +
        'deliberadamente pulverizada — o oposto de Pabrai.',
      valor: 59_922_860_164,
      posicoes: 424,
      posicoesAprox: true,
      posicoesDetalhe: [
        { t: 'GOOG', n: 'Alphabet',                  s: 'Comunicação',    p: 4.32, cls: 'Classe C' },
        { t: 'BDX',  n: 'Becton Dickinson',          s: 'Saúde',          p: 3.49 },
        { t: 'META', n: 'Meta Platforms',            s: 'Comunicação',    p: 3.03 },
        { t: 'TSM',  n: 'TSMC',                      s: 'Tecnologia',     p: 2.99 },
        { t: 'FMX',  n: 'Fomento Económico Mexicano', s: 'Consumo básico', p: 2.78 },
      ],
      demaisNota:
        'A cauda longa da carteira concentra a maior parte do valor: cerca de 419 posições ' +
        'sem peso individual divulgado, com 41 nomes adicionados no trimestre.',
      saidas: [
        { t: 'XOM', n: 'ExxonMobil', nota: 'saída integral — impacto de 1,79% na carteira' },
      ],
    },

    /* ---------------------------------------------------------------- */
    {
      id: 'lilu',
      nome: 'Li Lu',
      curto: 'Li Lu',
      gestora: 'Himalaya Capital Management',
      sigla: 'LL',
      base: 'Seattle, EUA',
      desde: 1997,
      lema: 'Cinco nomes que eu entendo melhor do que qualquer um',
      estilo:
        'O único gestor externo a quem Charlie Munger confiou dinheiro da família. ' +
        'Ponte entre o value investing americano e a China: carteira minúscula em ' +
        'número de nomes e enorme em convicção.',
      valor: 3_700_000_000,
      posicoes: 6,
      posicoesAprox: true,
      posicoesDetalhe: [
        { t: 'GOOGL', n: 'Alphabet',           s: 'Comunicação',            p: 24.55, cls: 'Classe A' },
        { t: 'GOOG',  n: 'Alphabet',           s: 'Comunicação',            p: 23.39, cls: 'Classe C' },
        { t: 'PDD',   n: 'PDD Holdings',       s: 'Consumo discricionário', p: 22.17, mov: 'add', movNota: 'posição ampliada em 133,5% — 6,15 mi de ações a ~US$ 92,32; total de 10,76 mi de ações (~US$ 821 mi)' },
        { t: 'BRK.B', n: 'Berkshire Hathaway', s: 'Financeiro',             p: 14.98, mov: 'add', movNota: 'posição ampliada em 23,46%' },
        { t: 'EWBC',  n: 'East West Bancorp',  s: 'Financeiro',             p:  9.68 },
      ],
      demaisNota: 'O restante da carteira não teve detalhamento por posição nas fontes consultadas.',
      saidas: [],
    },

    /* ---------------------------------------------------------------- */
    {
      id: 'klarman',
      nome: 'Seth Klarman',
      curto: 'Klarman',
      gestora: 'The Baupost Group',
      sigla: 'SK',
      base: 'Boston, EUA',
      desde: 1982,
      lema: 'Margem de segurança — e caixa não é vergonha',
      estilo:
        'Autor de "Margin of Safety". Trabalha em situações especiais, dívida ' +
        'distressed e eventos societários, e historicamente carrega caixa relevante ' +
        'quando não encontra preço. Metade da carteira 13F cabe em cinco nomes.',
      valor: 5_420_000_000,
      posicoes: 23,
      posicoesAprox: false,
      posicoesDetalhe: [
        { t: 'AMZN', n: 'Amazon',             s: 'Consumo discricionário', p: 16.48, mov: 'add', movNota: 'posição ampliada' },
        { t: 'ELV',  n: 'Elevance Health',    s: 'Saúde',                  p:  9.11 },
        { t: 'QSR',  n: 'Restaurant Brands',  s: 'Consumo discricionário', p:  9.04 },
        { t: 'GOOGL', n: 'Alphabet',          s: 'Comunicação',            p:  8.95, cls: 'Classe A', mov: 'add', movNota: 'posição ampliada' },
        { t: 'FERG', n: 'Ferguson',           s: 'Industrial',             p:  6.36, mov: 'add', movNota: 'posição ampliada' },
      ],
      demaisNota:
        'As 18 posições restantes não tiveram peso divulgado. Entradas do trimestre: ' +
        'Axalta Coating Systems (1,27 mi de ações), CME Group (619 mil ações) e Pershing Square Holdings. ' +
        'Também houve aumento em Genuine Parts e Norwegian Cruise Line.',
      saidas: [
        { t: 'WTW',   n: 'Willis Towers Watson', nota: 'saída integral' },
        { t: 'PCVX',  n: 'Vaxcyte',              nota: 'saída integral' },
      ],
    },

    /* ---------------------------------------------------------------- */
    {
      id: 'dorsey',
      nome: 'Pat Dorsey',
      curto: 'Dorsey',
      gestora: 'Dorsey Asset Management',
      sigla: 'PD',
      base: 'Chicago, EUA',
      desde: 2013,
      lema: 'Só compro fosso econômico com pista de crescimento',
      estilo:
        'Ex-diretor de research de ações da Morningstar e autor de "The Little Book ' +
        'That Builds Wealth". Aplica a taxonomia de moats — efeito de rede, custo de ' +
        'troca, ativo intangível, vantagem de custo — em uma carteira de ~11 nomes ' +
        'notavelmente equilibrada nos pesos.',
      valor: 1_560_000_000,
      posicoes: 11,
      posicoesAprox: false,
      posicoesDetalhe: [
        { t: 'ASML', n: 'ASML Holding',        s: 'Tecnologia',             p: 16.61 },
        { t: 'APP',  n: 'AppLovin',            s: 'Tecnologia',             p: 14.50 },
        { t: 'RPRX', n: 'Royalty Pharma',      s: 'Saúde',                  p:  8.82 },
        { t: 'BKNG', n: 'Booking Holdings',    s: 'Consumo discricionário', p:  8.46 },
        { t: 'SPGI', n: 'S&P Global',          s: 'Financeiro',             p:  8.25 },
        { t: 'UBER', n: 'Uber Technologies',   s: 'Tecnologia',             p:  8.14 },
        { t: 'LYV',  n: 'Live Nation',         s: 'Comunicação',            p:  7.69 },
        { t: 'DHR',  n: 'Danaher',             s: 'Saúde',                  p:  7.64 },
        { t: 'META', n: 'Meta Platforms',      s: 'Comunicação',            p:  7.21 },
        { t: 'AER',  n: 'AerCap Holdings',     s: 'Industrial',             p:  7.16 },
      ],
      demaisNota: 'Resta 1 posição sem peso divulgado.',
      saidas: [],
    },
  ],

  fontes: [
    { nome: 'SEC EDGAR — formulários 13F-HR', url: 'https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&type=13F' },
    { nome: 'Dataroma', url: 'https://www.dataroma.com/m/home.php' },
    { nome: 'GuruFocus', url: 'https://www.gurufocus.com/' },
    { nome: 'ValueSider', url: 'https://valuesider.com/' },
    { nome: 'WhaleWisdom', url: 'https://whalewisdom.com/' },
    { nome: "Acquirer's Multiple", url: 'https://acquirersmultiple.com/' },
    { nome: '13f.info', url: 'https://13f.info/' },
  ],
};
