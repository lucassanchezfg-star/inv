#!/usr/bin/env python3
"""
Gera dist/index.html: uma única página com CSS, dados e JS embutidos.

Serve para dois casos:
  • publicar como Artifact do Claude (o publicador injeta <!doctype>/<head>/<body>,
    por isso o arquivo gerado NÃO leva essas tags);
  • enviar por e-mail / abrir com duplo clique sem servidor.

Uso:  python build.py
"""

import io
import re
from pathlib import Path

RAIZ = Path(__file__).resolve().parent
DIST = RAIZ / "dist" / "index.html"


def ler(rel: str) -> str:
    return io.open(RAIZ / rel, encoding="utf-8").read()


def main() -> None:
    html = ler("index.html")
    css = ler("assets/style.css")
    dados = ler("data/carteiras.js")
    cotacoes = ler("data/cotacoes.js")
    app = ler("assets/app.js")

    # extrai o miolo entre <body> e </body>
    corpo = re.search(r"<body[^>]*>(.*)</body>", html, re.S)
    if not corpo:
        raise SystemExit("index.html: <body> não encontrado")
    corpo = corpo.group(1)

    # remove as tags <script src> locais — o JS entra embutido no fim
    corpo = re.sub(r'\s*<script src="(?:data|assets)/[^"]+"></script>', "", corpo)

    titulo = re.search(r"<title>(.*?)</title>", html, re.S).group(1).strip()
    fontes = re.findall(r'<link rel="(?:stylesheet|preconnect)"[^>]*>', html)
    fontes = [t for t in fontes if "fonts.g" in t]

    saida = (
        "<title>%s</title>\n" % titulo
        + "\n".join(fontes)
        + "\n<style>\n"
        + css
        + "\n</style>\n"
        + corpo.strip()
        + "\n\n<script>\n"
        + dados
        + "\n</script>\n<script>\n"
        + cotacoes
        + "\n</script>\n<script>\n"
        + app
        + "\n</script>\n"
    )

    DIST.parent.mkdir(parents=True, exist_ok=True)
    io.open(DIST, "w", encoding="utf-8", newline="\n").write(saida)
    print("dist/index.html gerado — %d KB" % (len(saida.encode("utf-8")) // 1024))


if __name__ == "__main__":
    main()
